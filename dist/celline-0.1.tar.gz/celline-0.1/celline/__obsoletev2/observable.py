# from typing import TYPE_CHECKING

# if TYPE_CHECKING:
#     from celline.interfaces import Project


# class Observable:
#     def __init__(self, project: Project) -> None:
#         print(project)
#         pass
