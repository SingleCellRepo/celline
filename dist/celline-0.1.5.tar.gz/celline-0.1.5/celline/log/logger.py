class Logger:
    @classmethod
    def build(cls):
        return ""
